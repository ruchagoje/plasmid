// Event listener for form submission
document.getElementById('registrationForm').addEventListener('submit', function(e) {
    e.preventDefault(); // Prevent form from submitting

    let valid = true;
    
    // Get form values
    let fullName = document.getElementById('fullName').value;
    let email = document.getElementById('email').value;
    let phoneNumber = document.getElementById('phoneNumber').value;
    let password = document.getElementById('password').value;
    let confirmPassword = document.getElementById('confirmPassword').value;

    // Full Name Validation: Minimum 5 characters and no numbers or special characters
    let namePattern = /^[a-zA-Z\s]+$/; // Allows only letters and spaces
    if (fullName.length < 5 || !namePattern.test(fullName)) {
        document.getElementById('nameError').innerText = "Full name must be at least 5 characters and contain only letters.";
        valid = false;
    } else {
        document.getElementById('nameError').innerText = "";
    }
    
    // Email Validation
    if (!email.includes('@')) {
        document.getElementById('emailError').innerText = "Enter a valid email address.";
        valid = false;
    } else {
        document.getElementById('emailError').innerText = "";
    }

    // Phone Number Validation
    if (phoneNumber === "123456789" || phoneNumber.length !== 10) {
        document.getElementById('phoneError').innerText = "Enter a valid 10-digit phone number.";
        valid = false;
    } else {
        document.getElementById('phoneError').innerText = "";
    }

    // Password Validation
    if (password.length < 8 || password.toLowerCase() === "password" || password.toLowerCase() === fullName.toLowerCase()) {
        document.getElementById('passwordError').innerText = "Password must be at least 8 characters and cannot be 'password' or your name.";
        valid = false;
    } else {
        document.getElementById('passwordError').innerText = "";
    }

    // Confirm Password Validation
    if (password !== confirmPassword) {
        document.getElementById('confirmPasswordError').innerText = "Passwords do not match.";
        valid = false;
    } else {
        document.getElementById('confirmPasswordError').innerText = "";
    }

    // If form is valid, alert success message
    if (valid) {
        alert("Form submitted successfully!");
    }
});

// Event listener for onChange (Optional: Improve user experience by adding real-time validation)
document.getElementById('fullName').addEventListener('change', function() {
    let fullName = document.getElementById('fullName').value;
    let namePattern = /^[a-zA-Z\s]+$/; // Allows only letters and spaces
    if (fullName.length < 5 || !namePattern.test(fullName)) {
        document.getElementById('nameError').innerText = "Full name must be at least 5 characters and contain only letters.";
    } else {
        document.getElementById('nameError').innerText = "";
    }
});

document.getElementById('email').addEventListener('change', function() {
    let email = document.getElementById('email').value;
    if (!email.includes('@')) {
        document.getElementById('emailError').innerText = "Enter a valid email address.";
    } else {
        document.getElementById('emailError').innerText = "";
    }
});

document.getElementById('phoneNumber').addEventListener('change', function() {
    let phoneNumber = document.getElementById('phoneNumber').value;
    if (phoneNumber === "123456789" || phoneNumber.length !== 10) {
        document.getElementById('phoneError').innerText = "Enter a valid 10-digit phone number.";
    } else {
        document.getElementById('phoneError').innerText = "";
    }
});

document.getElementById('password').addEventListener('change', function() {
    let password = document.getElementById('password').value;
    let fullName = document.getElementById('fullName').value;
    if (password.length < 8 || password.toLowerCase() === "password" || password.toLowerCase() === fullName.toLowerCase()) {
        document.getElementById('passwordError').innerText = "Password must be at least 8 characters and cannot be 'password' or your name.";
    } else {
        document.getElementById('passwordError').innerText = "";
    }
});

document.getElementById('confirmPassword').addEventListener('change', function() {
    let confirmPassword = document.getElementById('confirmPassword').value;
    let password = document.getElementById('password').value;
    if (password !== confirmPassword) {
        document.getElementById('confirmPasswordError').innerText = "Passwords do not match.";
    } else {
        document.getElementById('confirmPasswordError').innerText = "";
    }
});